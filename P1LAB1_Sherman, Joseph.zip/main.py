name=input()
print('Hello Pat and welcome to CS Online!')
